import React from "react";
import CQuizApp from "./CQuizApp";
export default function App() {
  return <CQuizApp />;
}
